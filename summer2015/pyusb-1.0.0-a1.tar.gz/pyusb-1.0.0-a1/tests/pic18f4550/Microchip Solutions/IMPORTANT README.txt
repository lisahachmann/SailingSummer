PIC USB Benchmark Firmware

DIRECTORY TREE:
 Device_Benchmark  - PIC USB Benchmark Firmware
 Microchip         - Original MCP USB Stack 2.6a files used by the benchmark
                     firmware. 

REQUIRED:
 * MCP USB Stack 2.6a
 * Microchip PIC USB Demo/Test Board

GETTING STARTED:
 * Move the "TestFirmware" folder to your 
   'Microchip Application Libraries' installation directory. This is normally 
   "C:\Microchip Solutions".
 
 * This firmware can use either libusb or winusb for a device driver.
